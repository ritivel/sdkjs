(function(){

	if (!Array.prototype.findIndex)
	{
		Object.defineProperty(Array.prototype, 'findIndex', {
			value: function(predicate) {
				if (this == null) {
					throw new TypeError('Array.prototype.findIndex called on null or undefined');
				}
				if (typeof predicate !== 'function') {
					throw new TypeError('predicate must be a function');
				}
				var list = Object(this);
				var length = list.length >>> 0;
				var thisArg = arguments[1];
				var value;

				for (var i = 0; i < length; i++) {
					value = list[i];
					if (predicate.call(thisArg, value, i, list)) {
						return i;
					}
				}
				return -1;
			}
		});
	}

	var typed_arrays = [
		Array,
		Int8Array,
		Uint8Array,
		Int16Array,
		Uint16Array,
		Int32Array,
		Uint32Array,
		Float32Array,
		Float64Array,
		Uint8ClampedArray
	];

	for (var i = 0, len = typed_arrays.length; i < len; i++)
	{
		var typed_array = typed_arrays[i];

		if (!typed_array.prototype.slice)
		{
			typed_array.prototype.slice = function(begin, end)
			{
				var len = this.length;
				var size;
				var start = begin || 0;

				start = (start >= 0) ? start : Math.max(0, len + start);
				end = end || len;

				var up_to = (typeof end == 'number') ? Math.min(end, len) : len;
				if (end < 0) up_to = len + end;

				// actual expected size of the slice
				size = up_to - start;

				// if size is negative it should return an empty array
				if (size <= 0) size = 0;

				var typed_array_constructor = this.constructor;
				var cloned = new typed_array_constructor(size);

				for (var i = 0; i < size; i++) {
					cloned[i] = this[start + i];
				}

				return cloned;
			};
		}

		if (!typed_array.prototype.fill)
		{
			typed_array.prototype.fill = function(value, begin, end)
			{
				var len = this.length;
				var size;
				var start = begin || 0;

				start = (start >= 0) ? start : Math.max(0, len + start);
				end = end || len;

				var up_to = (typeof end == 'number') ? Math.min(end, len) : len;
				if (end < 0) up_to = len + end;

				// actual expected size of the slice
				size = up_to - start;

				// if size is negative it should return an empty array
				if (size <= 0) size = 0;

				for (var i = 0; i < size; i++) {
					this[start + i] = value;
				}

				return this;
			};
		}
	}
	// https://tc39.github.io/ecma262/#sec-array.prototype.includes
	if (!Array.prototype.includes) {
		Object.defineProperty(Array.prototype, 'includes', {
			value: function(searchElement, fromIndex) {

				if (this == null) {
					throw new TypeError('"this" is null or not defined');
				}

				// 1. Let O be ? ToObject(this value).
				var o = Object(this);

				// 2. Let len be ? ToLength(? Get(O, "length")).
				var len = o.length >>> 0;

				// 3. If len is 0, return false.
				if (len === 0) {
					return false;
				}

				// 4. Let n be ? ToInteger(fromIndex).
				//    (If fromIndex is undefined, this step produces the value 0.)
				var n = fromIndex | 0;

				// 5. If n ≥ 0, then
				//  a. Let k be n.
				// 6. Else n < 0,
				//  a. Let k be len + n.
				//  b. If k < 0, let k be 0.
				var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

				function sameValueZero(x, y) {
					return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
				}

				// 7. Repeat, while k < len
				while (k < len) {
					// a. Let elementK be the result of ? Get(O, ! ToString(k)).
					// b. If SameValueZero(searchElement, elementK) is true, return true.
					if (sameValueZero(o[k], searchElement)) {
						return true;
					}
					// c. Increase k by 1.
					k++;
				}

				// 8. Return false
				return false;
			}
		});
	}

	// https://tc39.github.io/ecma262/#sec-array.prototype.find
	if (!Array.prototype.find) {
		Object.defineProperty(Array.prototype, 'find', {
			value: function(predicate) {
				// 1. Let O be ? ToObject(this value).
				if (this == null) {
					throw new TypeError('"this" is null or not defined');
				}

				var o = Object(this);

				// 2. Let len be ? ToLength(? Get(O, "length")).
				var len = o.length >>> 0;

				// 3. If IsCallable(predicate) is false, throw a TypeError exception.
				if (typeof predicate !== 'function') {
					throw new TypeError('predicate must be a function');
				}

				// 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
				var thisArg = arguments[1];

				// 5. Let k be 0.
				var k = 0;

				// 6. Repeat, while k < len
				while (k < len) {
					// a. Let Pk be ! ToString(k).
					// b. Let kValue be ? Get(O, Pk).
					// c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
					// d. If testResult is true, return kValue.
					var kValue = o[k];
					if (predicate.call(thisArg, kValue, k, o)) {
						return kValue;
					}
					// e. Increase k by 1.
					k++;
				}

				// 7. Return undefined.
				return undefined;
			},
			configurable: true,
			writable: true
		});
	}

	// ONLY FOR OLD CHROMIUM/V8
	if (window &&
		window.AscCommon &&
		window.AscCommon.AscBrowser &&
		window.AscCommon.AscBrowser.isChrome)
	{
		let typeOfValues = typeof Object.values;
		let isOld = typeOfValues === "undefined";
		if (!isOld && typeOfValues === "function")
		{
			if (Object.values.toString().indexOf("[native code]") === -1)
				isOld = true;
		}

		if (isOld)
		{
			(function() {
				var _sort = Array.prototype.sort;
				Array.prototype.sort = function(compareFn) {
					var len = this.length;

					var cmp = compareFn || function(a, b) {
						var sa = String(a);
						var sb = String(b);
						return sa < sb ? -1 : sa > sb ? 1 : 0;
					};

					var indexed = [];
					for (var i = 0; i < len; i++) {
						indexed.push({ v: this[i], i: i });
					}

					_sort.call(indexed, function(a, b) {
						var aVal = a.v;
						var bVal = b.v;

						var aIsUndefined = aVal === undefined;
						var bIsUndefined = bVal === undefined;

						if (aIsUndefined && bIsUndefined) return a.i - b.i;
						if (aIsUndefined) return 1;
						if (bIsUndefined) return -1;

						var r = cmp(aVal, bVal);

						if (typeof r !== 'number' || r !== r)
							r = 0;

						return r !== 0 ? r : a.i - b.i;
					});

					for (var i = 0; i < indexed.length; i++) {
						this[i] = indexed[i].v;
					}

					return this;
				};
			})();
		}
	}
})();
